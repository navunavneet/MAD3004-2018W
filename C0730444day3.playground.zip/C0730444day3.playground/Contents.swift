//: Playground - noun: a place where people can play

import UIKit

var namesOfInteger = [Int: String]()
print("nmaesOfInteger: \(namesOfInteger)")
namesOfInteger[16] = "Sixteen"
namesOfInteger[28] = "twenty eight"
if namesOfInteger.isEmpty {
    print("dictionary is empty")
}
else{
    print (namesOfInteger)
}
var airports: [String:String] = ["YYZ":"Toronto Pearson", "DUB":"Dublin"]
    airports["LHR"] = "London Heathrow"

    airports["YYZ"] = "TP International"

airports["XYZ"] = "SVP Inetrnational"
    print("airports : ",airports)

let oldValue = airports.updateValue("Dublin airport", forKey: "DUB")

if let airportName = airports["AMD"]{
print("the name of airport is \(airportName).")
}
print(airports)
airports["Mars"] = nil
if let removeValue = airports.removeValue(forKey: "DUB"){
 print("The removed airport's name is \(removeValue).")
}

for (airportCode,airportName) in airports{
    print(airportCode,airportName)
    
}
for airportCode in airports.keys{
    print("Airport code: \(airports)")
}
for airportName in airports.values{
    print("airport name: \(airportName)")
}
//<key,Value> pairs
var d1 : Dictionary<String, String> = ["India":"Hindi","Canada":"English"]
print(d1)
print(d1.description)
print(d1["India"]!)
print(d1["Canada"]!)
print(["USA"])
d1["China"] = "Mandarin"
for (k,v) in d1{
    
    print("\(k)-> \(v)")
}
//Dictionary with any values type
var d3 = [ String: AnyObject]()
d3["firstName"] = "jk" as AnyObject
d3["lastName"] = "patel" as AnyObject
d3["age"] = Int(50) as AnyObject
d3["salary"] = nil
print("d3",d3)

//Getting as a key , value pair
for (k,v) in d3{
    print("\(k) -> \(v)")
}
//Declaring tuples
var x = ( 10, 2, "Patel")
print(x.0)
print(x.1)
print(x.2)

let http404Error = (404, "Not Found")
print(http404Error)
let (statusCode, statusMessage) = http404Error
print("statusCode:",statusCode)
print("statusMessage:",statusMessage)

let (codeOnly,_) = http404Error
print("codeOnly:",codeOnly)
let errorDescription = (code: 404,Message: "Not Found")
print(errorDescription.code, errorDescription.Message)
//working with functions

//simple declaration
func add()
{
    print("I am in User Defined Function")
}
add()
func add(n1:Int, n2:Int){
    var sum : Int
    sum = n1 + n2
    print ("sum : ",sum)
}
add(n1:10,n2:20)

//Single Paramaeter
func welcome(name:String)
{

  print("Hello,\(name)")
}
func sub(a:Int, _ b:Int)
{
    let c = a - b
    print("Sub : \(c)")
}
sub(a: 30, 20)
//Single return type
func mul(a: Int, b: Int) -> Int
{
    let c = a * b
    return c
    func swipe(number1 a: Int, b: Int) -> (Int, Int)
    {
        return (b,a)
    }
    var (a,b) = swipe(number1: 10, b: 20)
    print("a: \(a), b: \(b)")
        (_, a) = swipe(number1: 10, b: 20)
        print("c : \(c)")
    }

var c = mul(a: 5, b: 2)
func swipe(aa: inout Double, bb: inout Double)
{
    let temp = aa
    aa = bb
    bb = temp
}

var a = 8.0, y = 9.0
swipe(aa:&a , bb:&y )
print("a : \(a), b: \(y)")

func simpleInterset(amount:Double, noOfYears: Double, rate:Double = 5.0) ->
    Double
{
    let si = amount * rate * noOfYears / 100
    return si
}

print("simple interst: \(simpleInterset(amount: 1000, noOfYears: 5))")
print("simple interst: \(simpleInterset(amount: 1000, noOfYears: 5,rate:10))")
func display(n:Int...)
{
    for i in n{
        print(i)
    }
}
display(n: 1,2,3,4,5)
display(n: 10,20,30)

//passing array as parameter
func display(arrayList:[Int]...)-> [Int]
{
    var array1 = arrayList[0]
 var array2 = arrayList[1]
var result = [Int]()

if array1.count == array2.count
{
    for i in 0..<array1.count
    {
    result.append(array1[i] + array2[i])
    }
    }
     return result
}
var a1 = [1,2,3,4,5]
var a2 = [10,11,12,13,14]
var a3 = display(arrayList:a1,a2)



